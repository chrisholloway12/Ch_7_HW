/* Ch_6_HW.cpp : Defines the entry point for the console application.

Program Name: Ch_6_HW
Developer: Chris Holloway
Date: 12/5/16
Purpose: Enter a students grades and demonstrate a loop
*/

#include "stdafx.h"
#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int numGrades, numStudents;
double assignments = 0;

double pts_poss(int num_assignments);
double ent_grd(int student_num, int grad_num);
double find_avg(double student_points, double totalPoints);

int main()
{
	//Prompt the user for the number of students
	cout << "Please enter the number of students: " << endl;
	cin >> numStudents;

	if (numStudents <= 0)
		cout << "Error: The number of students must be greater than 0 " << endl;
	else
	{

		//prompt the user for the number of grades
		cout << "Enter the number of grades for each student: " << endl;
		cin >> numGrades;
		cout << endl;

		if (numGrades <= 0)

			cout << "Error, the number of grades must be greater than 0" << endl;
		else
		{


			//use a loop to enter points for assignments 

			double grades;
			double total = 0.0;

			//prompt the user for number of points for each assignment

			int numSteps;
			numSteps = 1;
			while (numSteps <= numGrades)
			{
				grades = ent_grd(numStudents, numSteps);

				if (grades < 0)
				{
					cout << "Error, grade must be positive." << endl;
					numSteps--;
				}
				else
				{
					total = total + grades;
					numSteps++;
				}


			}

			cout << "The " << numGrades << " assignments are worth a total of " << total << " points." << endl;
			assignments = total;
			pts_poss(numGrades);
		}
	}
	system("PAUSE");
	return 0;
}
double pts_poss(int numAssignments)
{
	int numSteps2;
	numSteps2 = 1;
	int numSteps3;
	double grades2;
	do
	{

		double total2 = 0.0;
		for (numSteps3 = 1; numSteps3 <= numAssignments; numSteps3++)
		{
			cout << "Enter Student " << numSteps2 << "'s grade for assignment " << numSteps3 << endl;
			cin >> grades2;
			if (grades2 < 0)
			{
				cout << "Error, grade must be positive " << endl;
				numSteps3--;
			}
			else
			{
				total2 = total2 + grades2;
			}
		}
		cout << "The average for student " << numSteps2 << " is " << find_avg(total2, assignments) << endl;
		numSteps2++;
		//loop until number equals previously inputted amount
	} while (numSteps2 <= numStudents);
	return numAssignments;

}

double ent_grd(int student_num, int grad_num)
{
	double grade = 0.0;
	cout << "How many points is assignment " << grad_num << " worth? " << endl;
	cin >> grade;
	return grade;
}

double find_avg(double Student_points, double totalPoints)
{
	return Student_points / totalPoints * 100;
}

